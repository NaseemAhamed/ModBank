$ErrorActionPreference = 'Stop'
$webRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'app'))
$index = Join-Path $webRoot 'index.html'
if (-not (Test-Path -LiteralPath $index)) { throw 'Missing app/index.html. Copy the complete event package.' }
$port = 8765
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $port)
try { $listener.Start() }
catch { throw "Could not start ModBank on port $port. Another application may be using it. $_" }
$mime = @{
  '.html'='text/html; charset=utf-8'; '.js'='text/javascript; charset=utf-8';
  '.css'='text/css; charset=utf-8'; '.json'='application/json; charset=utf-8';
  '.svg'='image/svg+xml'; '.png'='image/png'; '.ico'='image/x-icon';
  '.woff'='font/woff'; '.woff2'='font/woff2'; '.txt'='text/plain; charset=utf-8';
  '.webp'='image/webp'; '.map'='application/json; charset=utf-8'
}
Write-Host 'ModBank is running at http://127.0.0.1:8765/' -ForegroundColor Green
Write-Host 'Leave this window open. Press Ctrl+C to stop.'
Start-Process 'http://127.0.0.1:8765/'
try {
  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $client.ReceiveTimeout = 5000; $client.SendTimeout = 5000
      $stream = $client.GetStream()
      $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
      $line = $reader.ReadLine()
      if ([string]::IsNullOrWhiteSpace($line)) { continue }
      $parts = $line.Split(' ')
      if ($parts.Length -lt 2) { continue }
      $method = $parts[0]
      $rawPath = $parts[1].Split('?')[0]
      while ($true) { $header = $reader.ReadLine(); if ($null -eq $header -or $header.Length -eq 0) { break } }
      if ($method -ne 'GET' -and $method -ne 'HEAD') {
        $status = '405 Method Not Allowed'; $bytes = [Text.Encoding]::UTF8.GetBytes('Method not allowed'); $type = 'text/plain'
      } else {
        try {
          $decoded = [uri]::UnescapeDataString($rawPath).Replace('/', [IO.Path]::DirectorySeparatorChar)
          $relative = $decoded.TrimStart([char[]]@('/', '\'))
          $candidate = [IO.Path]::GetFullPath((Join-Path $webRoot $relative))
          if (-not ($candidate -eq $webRoot -or $candidate.StartsWith($webRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase))) { throw 'Outside web root' }
          if ($relative -eq '' -or -not (Test-Path -LiteralPath $candidate -PathType Leaf)) { $candidate = $index }
          $bytes = [IO.File]::ReadAllBytes($candidate)
          $extension = [IO.Path]::GetExtension($candidate).ToLowerInvariant()
          $type = if ($mime.ContainsKey($extension)) { $mime[$extension] } else { 'application/octet-stream' }
          $status = '200 OK'
        } catch { $status = '400 Bad Request'; $bytes = [Text.Encoding]::UTF8.GetBytes('Bad request'); $type = 'text/plain' }
      }
      $headers = "HTTP/1.1 $status`r`nContent-Type: $type`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`nX-Content-Type-Options: nosniff`r`nCache-Control: no-cache`r`n`r`n"
      $headerBytes = [Text.Encoding]::ASCII.GetBytes($headers)
      $stream.Write($headerBytes, 0, $headerBytes.Length)
      if ($method -ne 'HEAD') { $stream.Write($bytes, 0, $bytes.Length) }
      $stream.Flush()
    } catch { Write-Warning "Request failed: $_" }
    finally { $client.Close() }
  }
} finally { $listener.Stop() }
