ModBank offline event

1. Extract the complete ModBank-Windows-Event folder on Windows.
2. Double-click Start-ModBank.cmd.
3. Your browser should open at http://127.0.0.1:8765/ .
4. Keep the PowerShell window open while students play.
5. Close it when finished.

No Docker, Node.js, Git or internet required on event machines.
If Windows blocks scripts, ask IT to approve the launcher.
