@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-ModBank.ps1"
if errorlevel 1 (
  echo.
  echo ModBank did not start. Contact the event organiser.
  pause
)
